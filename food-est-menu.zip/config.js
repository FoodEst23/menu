// config.js

export const GITHUB_CONFIG = {
    url: 'https://foodest23.github.io/menu/',
    owner: 'foodest23', // Sostituisci con il tuo username GitHub
    repo: 'menu',        // Sostituisci con il nome del tuo repository
    branch: 'main'                 // Sostituisci con il nome del branch principale (es. 'main' o 'master')
};