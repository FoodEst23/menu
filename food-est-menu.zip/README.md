https://foodest23.github.io/menu/
https://foodest23.github.io/menu/admin.html

npm start
http://127.0.0.1:8080/admin.html